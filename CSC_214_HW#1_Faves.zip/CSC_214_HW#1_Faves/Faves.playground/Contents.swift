//Name:                     Dominique Dorvil
//Email:                    ddorvil@u.rochester.edu
//Course:                   CSC 214 - Mobile App Development (iOS)
//Instructor:               Arthur Roolfs
//TA:                       Nicholas Romano
//Assignment/Project #:     Homework 1
//I did not get any unauthorized help for this assignment. To help with the hw I used the Apple Swift Online Text


import UIKit

                                    // SECTION 1

//initializing dict constant and filling dictionary
let playlist = ["Davido" : "Fall", "DaBaby" : "Goin Baby", "Doja Cat": "Juicy",
                "Smino": "Z4L", "Skepta" : "Bet", "Meg Thee Stallion"  : "Big Ole Freak",
                "Ski Mask The Slump God" : "Faucet Failure" , "Cardi B" : "Press",
                "Logic ft. Gucci Mane":"Icy", "P-Square" : "Personally"]

                                    // SECTION 2

// Get array of keys
print("Artists")
print("_________________")
print(" ")
var keys = Array(playlist.keys)
//print(playlist.keys)
for item in keys{
    print(item)
}

print(" ")
print("Artists")
print("_________________")
print(" ")
// Get array of values

var values = Array(playlist.values)
for item in values{
    print(item)
}


                                    // SECTION 3
print(" ")
let sortedKeys = keys.sorted()
print("These are the artists in alphabetical order: ")
print("_________________")
print(" ")
    for item in sortedKeys{
        print(item)
    }


print(" ")

let sortedValues = values.sorted()
print("These are the songs in alphabetical order: ")
print("_________________")
print(" ")
for item in sortedValues{
    print(item)
}


                                    // SECTION 4
print(" ")
print("Top 3 Artists")
print("_________________")
print(" ")
var setKeys = Set(keys)
for artist in ["Davido", "Doja Cat", "P-Square", "Skepta", "Cardi B", "Ski Mask The Slump God", "Smino"]{
    let artist = setKeys.remove(artist)
}
for rappers in setKeys {
    print(rappers)
}

print(" ")
print("Top 3 Songs ")
print("_________________")
print(" ")
var setValues = Set(values)
for songs in ["Personally", "Press", "Z4L", "Bet", "Icy", "Faucet Failure", "Big Ole Freak"]{
    let songs = setValues.remove(songs)
}
for hits in setValues {
    print(hits)
}

print()


                                    // SECTION 5

for rappers in setKeys {
    print("One of my favorite rappers is \(rappers)")
}


print()
for hits in setValues {
    print("One of my favorite songs is \(hits)")
}

