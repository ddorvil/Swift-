//
//  ColorManager.swift
//  CornerColors
//
//  Created by Dominique Dorvil on 9/15/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import Foundation
import UIKit

struct ColorManager {
    
    let squares: [UIColor]
    var index: Int
    
    mutating func getNextColor() -> UIColor {
        if index == squares.count {
            index = 0
        }
        
        let value = squares[index]
        index += 1
        
        return value
    }
    
    
}
