//
//  CornerColors.swift
//  CornerColors
//
//  Created by Dominique Dorvil on 9/15/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import Foundation
import UIKit

class CornerColors {
    
    private static let colorsArray = [
        UIColor.red,
        UIColor.cyan,
        UIColor.yellow,
        UIColor.magenta
        ]

var trSq = ColorManager(squares: colorsArray, index: 1)
var tlSq = ColorManager(squares: colorsArray, index: 2)
var brSq = ColorManager(squares: colorsArray, index: 3)
var blSq = ColorManager(squares: colorsArray, index: 4)


func block1() -> UIColor {
    return trSq.getNextColor()
}

func block2() -> UIColor {
        return tlSq.getNextColor()
    }
func block3() -> UIColor {
    return brSq.getNextColor()
}

func block4() -> UIColor {
    return blSq.getNextColor()
}
}
