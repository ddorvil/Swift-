//
//  ViewController.swift
//  CornerColors
//
//  Created by Dominique Dorvil on 9/14/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var ccView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        // go through color array with for loop
        // assign each
        
//        for item in colorsArray {
//            let color = colorsArray.randomElement() {
//            lbSq.backgroundColor = color
//
//            }
//    }

//    @IBOutlet weak var lbSq: UIView!
//    @IBOutlet weak var ltSq: UIView!
//    @IBOutlet weak var rtSq: UIView!
//    @IBOutlet weak var rbSq: UIView!
    
//    @IBAction func changeColor(_ sender: UIButton) {
//        let colorsArray = [UIColor.darkGray
//            UIColor.lightGray
//            UIColor.white
//            UIColor.gray
//            UIColor.red
//            UIColor.green
//            UIColor.blue
//            UIColor.cyan
//            UIColor.yellow
//            UIColor.magenta
//            UIColor.orange
//            UIColor.purple
//            UIColor.brown
//            UIColor.clear
//]
        
        
//        //TODO: Change on of the colors
//        print("will change color")
//        UIView.animate(withDuration: 1, animations:{
//            self.ccView.backgroundColor = UIColor.red)
//    }, completion: nil
//    }
//
//
//        for item in colorsArray {
//            let color = colorsArray.randomElement() {
//                UIView.animate(withDuration: 1, self.ccView.backgroundColor = item)
//
//            }}
//
//
//    }, completion: nil
    


    }}
