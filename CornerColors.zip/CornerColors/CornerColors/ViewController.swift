//
//  ViewController.swift
//  CornerColors
//
//  Created by Dominique Dorvil on 9/14/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    let Model = CornerColors()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        trSq_View.backgroundColor = Model.block1()
        tlSq_View.backgroundColor = Model.block2()
        brSq_View.backgroundColor = Model.block3()
        blSq_View.backgroundColor = Model.block4()
        
    }
    

    @IBAction func ChangeColorBtn(_ sender: Any) {
        
        trSq_View.backgroundColor = Model.block1()
        tlSq_View.backgroundColor = Model.block2()
        brSq_View.backgroundColor = Model.block3()
        blSq_View.backgroundColor = Model.block4()
        
    }
    
    @IBOutlet weak var ChangeColorBtn_outlet: UIButton!
    
   
    @IBOutlet weak var trSq_View: UIView!
    
    
    @IBOutlet weak var brSq_View: UIView!
    
    
    @IBOutlet weak var tlSq_View: UIView!
    @IBOutlet weak var blSq_View: UIView!
}


