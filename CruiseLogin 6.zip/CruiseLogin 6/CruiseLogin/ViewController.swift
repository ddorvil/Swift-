//
//  ViewController.swift
//  CruiseLogin
//
//  Created by Dominique Dorvil on 10/8/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import UIKit

class ViewController: UIViewController{

    @IBOutlet weak var stackAni: UIStackView!
    @IBOutlet weak var background: UIImageView!
    @IBOutlet weak var boatImage: UIImageView!
    @IBOutlet weak var rockTitle: NSLayoutConstraint!
    @IBOutlet weak var theTitle: NSLayoutConstraint!
    @IBOutlet weak var boatTitle: NSLayoutConstraint!
    @IBOutlet weak var rockLabel: UILabel!
    @IBOutlet weak var theLabel: UILabel!
    @IBOutlet weak var boatLabel: UILabel!
    @IBOutlet weak var btnName: UIButton!
    
    //nested animation & stack animation
    @IBAction func btnMove(_ sender: UIButton) {
        print("button pressed")
        //going up
        UIView.animate(withDuration: 1, animations: {
            self.boatImage.frame.origin.y -= 15
            self.stackAni.frame.origin.y -= 15
        }, completion: {_ in//going left
            UIView.animate(withDuration: 3, animations: {
                self.boatImage.frame.origin.x -= 80
                self.stackAni.frame.origin.x -= 80
            }, completion: {_ in
                //going right
                UIView.animate(withDuration: 6, animations: {
                    self.boatImage.frame.origin.x += 80
                    self.stackAni.frame.origin.x += 80
                }, completion: {_ in
                    //going left
                    UIView.animate(withDuration: 3, animations: {
                        self.boatImage.frame.origin.x -= 50
                        self.stackAni.frame.origin.x -= 50
                    }, completion: nil)})
            })
        })
}
    
    //Localization
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "ROCK THE BOAT"
        rockLabel.text = NSLocalizedString("str_rock", comment: "")
        theLabel.text = NSLocalizedString("str_the", comment: "")
        boatLabel.text = NSLocalizedString("str_boat", comment: "")
        btnName.setTitle(NSLocalizedString("str_btn", comment: ""), for: .normal)
        background.alpha = 0
    }

    // animation on the constraint
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        imageFadeIn(imageView: background)
//        let firstImageView = UIImageView(image: UIImage(named: "background1.png"))
//        firstImageView.frame = view.frame
//        view.addSubview(firstImageView)
//        firstImageView.sendSubviewToBack(self.view)
        
        UIView.animate(withDuration: 0.10, delay: 0.9, options: UIView.AnimationOptions.curveEaseOut, animations: {
            self.rockTitle.constant += 45
            self.view.layoutIfNeeded()
        }, completion: nil)
        
        UIView.animate(withDuration: 0.10, delay: 0.5, options: .curveEaseOut, animations: {
            self.theTitle.constant += 45
            self.view.layoutIfNeeded()
        }, completion: nil)
        
        UIView.animate(withDuration: 0.10, delay: 0.3, options: .curveEaseOut, animations: {
            self.boatTitle.constant += 45
            self.view.layoutIfNeeded()
        }, completion: nil)
        
        
    }

    //alpha animation
    func imageFadeIn(imageView: UIImageView) {
        
        UIView.animate(withDuration: 2.0, delay: 2.0, options: .curveEaseOut, animations: {
            imageView.alpha = 1.0
        }, completion: {_ in
            
            imageView.image = UIImage(named: "background2.png")
        
        })
//        UIView.animate(withDuration: 2, animations: {imageView.alpha = 0})
    }
    
    

}

