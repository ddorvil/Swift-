//
//  Constants.swift
//  quiz
//
//  Created by Dominique Dorvil on 12/4/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import Foundation

import UIKit

/*
 ** default items
 */

let dShowDailyTip           = "show_daily_tip"
let dDarkMode               = "dark_mode"
let dPinkMode               = "pink_mode"

