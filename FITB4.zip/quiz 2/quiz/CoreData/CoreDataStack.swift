//
//  CoreDataStack.swift
//  quiz
//
//  Created by Dominique Dorvil on 12/2/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import Foundation
import CoreData

final class CoreDataStack: NSObject {
    
    static let shared = CoreDataStack()
    
    let modelName = "Model"
    
    lazy var context: NSManagedObjectContext = {
        return self.persistentContainer.viewContext
    }()
    
    lazy var persistentContainer: NSPersistentContainer = {
        
        let container = NSPersistentContainer(name: "Model")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    var items: [NSManagedObject] = []
    
    // MARK: - Core Data operations
    
    func update() {
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Game")
        do {
            items = try context.fetch(fetchRequest)
        } catch let error as NSError {
            print("Could not fetch requested Game. \(error), \(error.userInfo)")
        }
    }
    
    func saveItem(titleName: String, bookName: Int16, bookCover: NSData, rating: Int16, score: Int16) {
        
        if let entity = NSEntityDescription.entity(forEntityName: "Game", in: context) {
            let item = NSManagedObject(entity: entity, insertInto: context)
            item.setValue(titleName, forKeyPath: "titleName")
            item.setValue(bookName, forKeyPath: "bookName")
            item.setValue(bookCover, forKeyPath: "bookCover")
            item.setValue(rating, forKeyPath: "rating")
            item.setValue(score, forKeyPath: "score")
            do {
                try context.save()
            } catch let error as NSError {
                print("Could not save the item. \(error), \(error.userInfo)")
            }
        }
        update()
    }
    
    func deleteItem(item: Game) {
        if let _ = items.firstIndex(of: item)  {
            context.delete(item)
            do {
                try context.save()
            } catch let error as NSError {
                print("Could not delete the item. \(error), \(error.userInfo)")
            }
        }
        update()
    }
    
    func saveContext () {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    
}

