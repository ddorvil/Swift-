//
//  Game+CoreDataClass.swift
//  quiz
//
//  Created by Dominique Dorvil on 12/3/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Game)
public class Game: NSManagedObject {
    
    override public func awakeFromInsert() {
        if self.uuid == nil {
            self.uuid = UUID()
        }
    }

}
