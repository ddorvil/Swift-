//
//  Game+CoreDataProperties.swift
//  quiz
//
//  Created by Dominique Dorvil on 12/3/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//
//

import Foundation
import CoreData


extension Game {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Game> {
        return NSFetchRequest<Game>(entityName: "Game")
    }

    @NSManaged public var bookCover: NSData?
    @NSManaged public var bookName: Int16
    @NSManaged public var rating: Int16
    @NSManaged public var score: Int16
    @NSManaged public var titleName: String?
    @NSManaged public var uuid: UUID?

}
