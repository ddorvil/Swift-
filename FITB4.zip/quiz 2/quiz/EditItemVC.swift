//
//  EditItemVC.swift
//  quiz
//
//  Created by Dominique Dorvil on 12/1/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import UIKit

protocol EditItemDelegate: class {
    func addedGameItem()
}

var flag: Int = 0

class EditItemVC: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate, UITextFieldDelegate{

    
    @IBOutlet weak var playBtn: UIButton!
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet weak var bookCoverPicker: UIImageView!
    @IBOutlet weak var companyName: UIImageView!
    @IBOutlet weak var selectBook: UIPickerView!
    var bookData: [String] = [String]()
    @IBOutlet weak var inputTitle: UITextField!
    @IBOutlet weak var emojiPicker: UIPickerView!
    var emojiData: [String] = [String]()
    
    var titleName: String?
    var points: Int16?
    var bookImage: UIImage?
    
    //LABELS
    
    @IBOutlet weak var book: UILabel!
    
    @IBOutlet weak var bookc: UILabel!
    
    @IBOutlet weak var reaction: UILabel!
    @IBOutlet weak var header: UILabel!
    weak var delegate: EditItemDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        playBtn.layer.cornerRadius = 25.0
        cancelBtn.layer.cornerRadius = 25.0
        
        self.selectBook.delegate = self
        self.selectBook.dataSource = self
        
        self.emojiPicker.delegate = self
        self.emojiPicker.dataSource = self
    
        book.text = NSLocalizedString("str_books", comment: "")
        bookc.text = NSLocalizedString("str_book_cover", comment: "")
        
        playBtn.setTitle(NSLocalizedString("str_playBtn", comment: ""), for: .normal)
        cancelBtn.setTitle(NSLocalizedString("str_cancelBtn", comment: ""), for: .normal)
        
        
        bookData = [NSLocalizedString("book1", comment: ""), NSLocalizedString("book2", comment: ""),NSLocalizedString("book3", comment: "")]
        
         bookData = ["College Acceptance", "Email to Professor", "Pick Up Lines"]
        
        
        
        emojiData = ["😂", "😕" , "😏", "😅", "😑"]
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(bookCoverChange))
        tap.numberOfTapsRequired = 1
        view.addGestureRecognizer(tap)
        
        imageFadeIn(imageView: companyName)
    }
    
    //alpha animation
    func imageFadeIn(imageView: UIImageView) {
        
        UIView.animate(withDuration: 2.0, delay: 2.0, options: .curveEaseOut, animations: {
            imageView.alpha = 1.0
        }, completion: {_ in
            
            imageView.image = UIImage(named: "Icon-1024.png")
            
        })
        //        UIView.animate(withDuration: 2, animations: {imageView.alpha = 0})
    }
    
    @IBOutlet var coverChange: UITapGestureRecognizer!
    
    //book cover changes with tap
    @IBAction func bookCoverChange(_ sender: UITapGestureRecognizer) {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.allowsEditing = true
        picker.sourceType = .photoLibrary
        present(picker, animated: true, completion: nil)
        flag = 1;
    }

    
    
    @IBAction func onTitleChange(_ sender: UITextField) {
        
        if let newValue = sender.text {
            if newValue == "" {
                titleAlert()
            }
            titleName = newValue
        }
        else {
            titleAlert()
        }
    }
    
    @IBAction func onCancel(_ sender: UIButton) {
        presentingViewController?.dismiss(animated: true)
    }
    
    
    @IBAction func onPlay(_ sender: UIButton) {
        
        if inputTitle.text == nil {
            titleAlert()
        }
        
        if let title = titleName, let bookPic = bookImage {
            if titleName == nil {
                titleAlert()
            }
            CoreDataStack.shared.saveItem(titleName: title,
                                          bookName: Int16(selectBook.selectedRow(inComponent:0)),
                                          bookCover: bookPic.pngData()! as NSData, rating: Int16(emojiPicker.selectedRow(inComponent: 0)),
                                          score: points!)
            
                                          delegate?.addedGameItem()
        }
//         presentingViewController?.dismiss(animated: true)
        
    }
    
    //ALERTS
    
    func titleAlert() {
        
        let alertMsg = "Missing title!"
        let alert = UIAlertController(title: "Warning", message: alertMsg, preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler:nil)
        
        alert.addAction(cancelAction)
        
        /*
         **  In this case we need a source for the popover as well, but don't have a handy UIBarButtonItem.
         **  As alternative we therefore use the sourceView/sourceRect combination and specify a rectangel
         **  centered in the view of our viewController.
         */
        alert.popoverPresentationController?.permittedArrowDirections = []
        alert.popoverPresentationController?.sourceView = self.view
        alert.popoverPresentationController?.sourceRect = CGRect(x: self.view.frame.midX, y: self.view.frame.midY, width: 0, height: 0)
        
        present(alert, animated: true, completion: nil)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - UIImagePickerControllerDelegate
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[.editedImage] as? UIImage  {
            if flag == 1 {
                bookCoverPicker.image = image
            }
        }
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
    
}

extension EditItemVC: UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView.tag == 0 {
            return bookType.allValues.count
        } else if pickerView.tag == 1 {
            return reactionType.allValues.count
        } else {
            return reactionType.allValues.count
    }
    }

}
extension EditItemVC: UIPickerViewDelegate {
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> UIImage? {
        if pickerView.tag == 1 {
            print(reactionType.self)
            return reactionType(rawValue: row)?.image()
        }
        return reactionType(rawValue: row)?.image()
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView.tag == 0 {
            print("Hello", (bookData))
            return bookData[row]
        }
        
        else{
            return reactionType(rawValue: row)?.title()
        }
    }
}


