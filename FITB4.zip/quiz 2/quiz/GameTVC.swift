//
//  GameTableViewController.swift
//  quiz
//
//  Created by Dominique Dorvil on 11/27/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import UIKit

class LibsTVC: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // It is necessary to do this here because of a bug in storyboard editor
        self.title = Bundle.main.object(forInfoDictionaryKey: "CFBundleName") as? String
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    func numberOfSections(_ tableView: UITableView, numberOfRowsInSection section:Int) -> Int {
        return 1
    }

        override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "LibsTVC"
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath) as? LibsTVC  else {
            fatalError("The dequeued cell is not an instance of LibsTVCell.")
        }
        
        //You can add sample cells here
        
        return cell
    }
    
    // disallow swipe deletion when not in edit mode
    #if !DEBUG
    override func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return tableView.isEditing ? .delete : .none
    }
    #endif
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
//            if let item = CoreDataStack.shared.entries[indexPath.row] as? Entry {
//                deletionAlert(title: item.name!) { _ in
//                    CoreDataStack.shared.deleteItem(item: item)
//                    self.tableView.reloadData()
//                }
//            }
        }
    }
    
    // MARK: - Deletion Alert
    
    func deletionAlert(title: String, completion: @escaping (UIAlertAction) -> Void) {
        
        let alertMsg = "Are you sure you want to delete \(title)? This cannot be undone!"
        let alert = UIAlertController(title: "Warning", message: alertMsg, preferredStyle: .actionSheet)
        
        let deleteAction = UIAlertAction(title: "Delete", style: .destructive, handler: completion)
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler:nil)
        
        alert.addAction(cancelAction)
        alert.addAction(deleteAction)
        
        /*
         **  In this case we need a source for the popover as well, but don't have a handy UIBarButtonItem.
         **  As alternative we therefore use the sourceView/sourceRect combination and specify a rectangel
         **  centered in the view of our viewController.
         */
        alert.popoverPresentationController?.permittedArrowDirections = []
        alert.popoverPresentationController?.sourceView = self.view
        alert.popoverPresentationController?.sourceRect = CGRect(x: self.view.frame.midX, y: self.view.frame.midY, width: 0, height: 0)
        
        present(alert, animated: true, completion: nil)
    }
    
    

    // MARK: - Actions

    @IBAction func onToggleEditing(_ sender: UIBarButtonItem) {
        setEditing(!isEditing, animated: true)
    }

}
