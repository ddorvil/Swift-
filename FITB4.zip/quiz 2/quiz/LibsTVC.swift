//
//  GameTableViewController.swift
//  quiz
//
//  Created by Dominique Dorvil on 11/27/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import UIKit
import CoreData

class LibsTVC: UITableViewController, EditItemDelegate, UITextFieldDelegate {

    
    var chapter = [String]()
    var newChapter: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        aboutUsAlert()
       
        
         chapter = ["Chapter 1", "Chapter 2", "Chapter 3"]
        
        CoreDataStack.shared.update()
        // It is necessary to do this here because of a bug in storyboard editor
        self.title = Bundle.main.object(forInfoDictionaryKey: "CFBundleName") as? String
        
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = UITableView.automaticDimension
        tableView.reloadData()
    }
    
    func aboutUsAlert() {
        let alertController = UIAlertController(title: "Fill in the Blank", message: "This game is an imitation of Mad Libs. Fill in the blanks to reveal a funny story!", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Dismiss", style: .default))
        self.present(alertController, animated: true, completion: nil)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    @IBAction func onSwipe(_ sender: UISwipeGestureRecognizer) {
        switch sender.direction {
        case .down:
            performSegue(withIdentifier: "showSettingsSegue", sender: self)
        default: break
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier {
            case "EditItemSegue":
                if let vc = segue.destination as? EditItemVC {
                    vc.delegate = self
                }
    
            case "clickStory":
                if let vc = segue.destination as? StoryTVC {
                    if let indexPath = tableView.indexPathForSelectedRow {
                        vc.item = CoreDataStack.shared.items[indexPath.row] as? Game
                    }
                }
        
            
        default:
            fatalError("Invalid segue identifier")
        }
    }
    
    
   
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return CoreDataStack.shared.items.count
    }
    
   override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "LibsTVCell") as? LibsTVCell else {
            fatalError("Expected LibsTVCell")
        }
        
    
        
        cell.titleLabel?.text = chapter[indexPath.row]
        
        if let item = CoreDataStack.shared.items[indexPath.row] as? Game {
            cell.titleLabel?.text = item.titleName
//            cell.bookLabel?.text = item.bookName
            cell.updateBookName(type: Int(item.bookName))
//            cell.scoreLabel(type: Int(item.score))
            cell.updateScore(type: Int(item.score))
            cell.storyImage.image = UIImage(data: item.bookCover! as Data)
            cell.updateReaction(type: Int(item.rating))
            
        }
        
        //You can add sample cells here
        
        return cell
    }
    
    // disallow swipe deletion when not in edit mode
    #if !DEBUG
    override func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return tableView.isEditing ? .delete : .none
    }
    #endif
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
                        if let item = CoreDataStack.shared.items[indexPath.row] as? Game {
                            deletionAlert(title: item.titleName!) { _ in
                                CoreDataStack.shared.deleteItem(item: item)
                                self.tableView.reloadData()
                            }
                        }
        }
    }
    
    // MARK: - Deletion Alert
    
    func deletionAlert(title: String, completion: @escaping (UIAlertAction) -> Void) {
        
        let alertMsg = "Are you sure you want to delete \(title)? This cannot be undone!"
        let alert = UIAlertController(title: "Warning", message: alertMsg, preferredStyle: .actionSheet)
        
        let deleteAction = UIAlertAction(title: "Delete", style: .destructive, handler: completion)
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler:nil)
        
        alert.addAction(cancelAction)
        alert.addAction(deleteAction)
        
        /*
         **  In this case we need a source for the popover as well, but don't have a handy UIBarButtonItem.
         **  As alternative we therefore use the sourceView/sourceRect combination and specify a rectangel
         **  centered in the view of our viewController.
         */
        alert.popoverPresentationController?.permittedArrowDirections = []
        alert.popoverPresentationController?.sourceView = self.view
        alert.popoverPresentationController?.sourceRect = CGRect(x: self.view.frame.midX, y: self.view.frame.midY, width: 0, height: 0)
        
        present(alert, animated: true, completion: nil)
    }
    
    // MARK: -Delegate
    
    func addedGameItem() {
        tableView.reloadData()
    }
    
    // MARK: - Actions
    
    @IBAction func onToggleEditing(_ sender: UIBarButtonItem) {
        setEditing(!isEditing, animated: true)
    }
    
}

