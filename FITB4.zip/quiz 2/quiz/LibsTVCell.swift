//
//  LibsTVCell.swift
//  quiz
//
//  Created by Dominique Dorvil on 12/1/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import UIKit

class LibsTVCell: UITableViewCell {
    
    //MARK: Properties
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var bookLabel: UILabel!
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var storyImage: UIImageView!
    @IBOutlet weak var ratingImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func updateReaction(type: Int) {
        if let type = reactionType(rawValue: type){
            ratingImageView.image = type.image()
        }
    
    }
    
//    func updateBookImage(type: Int) {
//        if let type = bookType(rawValue: type){
//            storyImage.image = type.title()()
//        }
//        
//    }
    
    func updateBookName(type: Int) {
        if let bType = bookType(rawValue: type) {
            bookLabel.text = bType.title()
        }
    }
    
    
    func updateScore(type: Int){
       scoreLabel.text = "0"
    }
    
}
