//
//  StoryTVC.swift
//  quiz
//
//  Created by Dominique Dorvil on 12/1/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import UIKit


class StoryTVC: UIViewController  {
    
    var item: Game?
    
    @IBOutlet weak var storyAni: NSLayoutConstraint!
    @IBOutlet weak var reactionPicker: UIPickerView!
    var reactionData: [UIImage] = [UIImage]()
    
    
    @IBAction func storyLabel(_ sender: UITapGestureRecognizer) {
        storyAlert()
    }
    
    @IBOutlet weak var story: UILabel!
    
    func storyAlert() {
        let alertController = UIAlertController(title: "Warning", message: "Funny Stories Awaits!", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Dismiss", style: .default))
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    var blank1:String = ""
    var blank2:String = ""
    var blank3:String = ""
    var blank4:String = ""
    var blank5:String = ""
    var blank6:String = ""
    var blank7:String = ""
    var blank8:String = ""
    var blank9:String = ""
    var blank10:String = ""
    
        
    @IBOutlet weak var storyStack: UIStackView!
    @IBOutlet weak var Line1: UILabel!
    @IBOutlet weak var Line2: UILabel!
    @IBOutlet weak var Line3: UILabel!
    @IBOutlet weak var Line4: UILabel!
    @IBOutlet weak var Line5: UILabel!
    @IBOutlet weak var Line6: UILabel!
    @IBOutlet weak var Line7: UILabel!
    @IBOutlet weak var Line8: UILabel!
    @IBOutlet weak var Line9: UILabel!
    @IBOutlet weak var Line10: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        story.text = NSLocalizedString("str_story", comment: "")
        Line1.text = NSLocalizedString("str_line1", comment: "")
        Line2.text = NSLocalizedString("str_line2", comment: "")
        Line3.text = NSLocalizedString("str_line3", comment: "")
        Line4.text = NSLocalizedString("str_line4", comment: "")
        Line5.text = NSLocalizedString("str_line5", comment: "")
        Line6.text = NSLocalizedString("str_line6", comment: "")
        Line7.text = NSLocalizedString("str_line7", comment: "")
        Line8.text = NSLocalizedString("str_line8", comment: "")
        Line9.text = NSLocalizedString("str_line9", comment: "")
        Line10.text = NSLocalizedString("str_line10", comment: "")
        
//        self.reactionPicker.delegate = self as? UIPickerViewDelegate
//        self.reactionPicker.dataSource = self
        
        Line1?.text = "Are you from \(blank1)?"
        Line2?.text = "Because you are the only \(blank2) I see."
        Line3?.text = "Hi, the \(blank3) in my"
        Line4?.text = " \(blank4) told me to come over and talk to you."
        Line5?.text = "I'd marry your \(blank5) just to get in the family."
        Line6?.text = "Can I have directions? From here to your \(blank6)"
        Line7?.text = "Do you have a BandAid? I just \(blank7)"
        Line8?.text = " my \(blank8)"
        Line9?.text = " \(blank9) fo you."
        Line10?.text = "Do you have a map? I'm gettign lost in your \(blank10)."
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
//        UIView.animate(withDuration: 1, animations: {
//            self.storyAni.constant -= 45
//        }, completion: {_ in//going left
//            UIView.animate(withDuration: 3, animations: {
//                self.storyAni.constant -= 20
//            }, completion: {_ in
//                //going right
//                UIView.animate(withDuration: 6, animations: {
//                    self.storyAni.constant += 80
//                }, completion: {_ in
//                    //going left
//                    UIView.animate(withDuration: 3, animations: {
//                        self.storyAni.constant -= 50
//                    }, completion: nil)})
//            })
//        })
        
        UIView.animate(withDuration: 0.10, delay: 0.9, options: UIView.AnimationOptions.curveEaseOut, animations: {
            self.storyAni.constant += 135
            self.view.layoutIfNeeded()
        }, completion: {_ in
        
        UIView.animate(withDuration: 0.10, delay: 0.5, options: .curveEaseOut, animations: {
            self.storyAni.constant -= 270
            self.view.layoutIfNeeded()
        }, completion: {_ in
        
        UIView.animate(withDuration: 0.10, delay: 0.3, options: .curveEaseOut, animations: {
            self.storyAni.constant += 135
            self.view.layoutIfNeeded()
        }, completion: nil)})
        
        })
  
    }
    
    
    //this is where the different stories will have to be
    
    }

//These pickers need to be edited. I am a little confused on what's going on
//extension StoryTVC: UIPickerViewDataSource {
//    func numberOfComponents(in pickerView: UIPickerView) -> Int {
//        return 1
//    }
//    
//    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
//        if pickerView.tag == 0 {
//            return reactionData.count
//        }
//    }
//    
//    func pickerView(pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
//        return 60
//    }
//}
//extension EditItemVC: UIPickerViewDelegate {
//    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> UIImage? {
//        if pickerView.tag == 0 {
//            return reactionData[row]
//        } else {
//            reactionType(rawValue: row)?.image()
//        }
//    }
//}
