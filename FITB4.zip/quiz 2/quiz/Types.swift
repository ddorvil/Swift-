//
//  Types.swift
//  quiz
//
//  Created by Dominique Dorvil on 12/2/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import Foundation
import UIKit

enum reactionType: Int {
    case flushed, nervous, nomouth, tears, unamused
    static let allValues = [flushed, nervous, nomouth, tears, unamused]
    
    func title() -> String {
        switch self {
//        case .flushed:
//            return "Flushed Emoji"
//        case .nervous:
//            return "Nervous Emoji"
//        case .nomouth:
//            return "No Mouth Emoji"
//        case .tears:
//            return "Tearful Laugh Emoji"
//        case .unamused:
//            return "Unamused Emoji"
            
        case .flushed:
            return "😂"
        case .nervous:
            return "😕"
        case .nomouth:
            return "😏"
        case .tears:
            return "😅"
        case .unamused:
            return "😑"
        }
    }
    
    func image() -> UIImage? {
        switch self {
        case .flushed:
            return UIImage(named: "type_flushed")
        case .nervous:
            return UIImage(named: "type_nervous")
        case .nomouth:
            return UIImage(named: "type_nomouth")
        case .tears:
            return UIImage(named: "type_tears")
        case .unamused:
            return UIImage(named: "type_unamused")
            
            
        }
    }
    
}

enum bookType: Int {
    case book1, book2, book3
    static let allValues = [book1, book2, book3]
    
    func title() -> String {
        switch self {
        case .book1:
            return "College Acceptance"
        case .book2:
            return "Email to Professor"
        case .book3:
            return "Pick Up Lines"
        }
    }
    
}
