//
//  userHelp.swift
//  quiz
//
//  Created by Dominique Dorvil on 12/1/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import UIKit

class userHelp {
    
    func generate() -> String? {
            
            let word = ["A", "B", "C", "D"]
            
//            let ranWord = word[Int.random(in: 0..<word.count)]
        
            var genArr = [word]
            
            genArr.shuffle()
            
//            var words = ""
        
        //        Next task: make the generate button work, then add all the core data stuff and the fifth element. Also figure out how to do the uicollection thing.
        
//            for c in genArr{
//                words = c
//            }
        
            //        var strength = 5
            
//            print(words)
//
//
            return ""
        
        }
}
