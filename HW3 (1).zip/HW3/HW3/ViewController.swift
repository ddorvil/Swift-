//
//  ViewController.swift
//  HW3
//
//  Created by Dominique Dorvil on 9/22/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate{

    @IBOutlet weak var textView: UILabel!
    @IBOutlet weak var textField: UITextField!
    
    @IBAction func onTextInput(_ sender: UITextField) {
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        super.viewDidLoad()
        textField.delegate = self
        textField.becomeFirstResponder()
        textField.autocapitalizationType = .allCharacters
    }
    
//    func isValidInput(inputString: String) -> Bool {
//        if inputString.count == 0 {
//            return true
//        }
//        return true
//    }



func makeDigitsString(inputString: String) -> String {
    //            if let current = textField.text, !current.isEmpty{
    //                return sender.text!
    //            }else if sender.text!.count <= 1 {
    //                var replacementString = ""
    //                for character in textView.text! {
    //                    if String(character) != sender.text! {
    //                        replacementString.append(character)
    //                    } else {
    //                        replacementString.append("*")
    //                    }
    //                    textView.text = replacementString
    //                }
    //                return replacementString
    //            } else {
    //                return sender.text!
    //            }
    //
    var outputString = ""
    
    //inputString.index(inputString.startIndex, offsetBy: 1)
    for _ in inputString {
        outputString.append("9")
    }
    return outputString
}
}
extension ViewController {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        onTextInput(textField)
        
         textView.text = textField.text!
        
        
        let currText = textField.text ?? ""
        guard let stringRange = Range(range, in: currText) else { return false }
        let updatedText = currText.replacingCharacters(in: stringRange, with: string)
        
        return updatedText.count <= 7
        

        
    }
    
}



