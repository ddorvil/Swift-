//
//  TableViewController.swift
//  HW5
//
//  Created by Dominique Dorvil on 10/18/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import UIKit
import CoreData

class TableViewController: UITableViewController {
    
    var media: [NSManagedObject] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Password Manager"
        updateFromModel()
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return media.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "UITableViewCell", for: indexPath)
        let item = media[indexPath.row]
        cell.textLabel?.text = item.value(forKeyPath: "title") as? String
        
        // if we were updating the subtitle cell we would do it here
        cell.detailTextLabel?.text = item.value(forKeyPath: "password") as? String
        
        return cell
    }
    
    // MARK: - Core Data
    
    func updateFromModel() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Manager")
        
        do {
            media = try managedContext.fetch(fetchRequest)
        } catch let error as NSError {
            print("Could not fetch requested media. \(error), \(error.userInfo)")
        }
    }
    
    // if we had 2 strings to save we would write this function like so instead:
     func saveSong(title: String, password: String) {
//    func saveSong(title: String) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "Manager", in: managedContext)!
        
        let song = NSManagedObject(entity: entity, insertInto: managedContext)
        song.setValue(title, forKeyPath: "title")
        
        // if we had 2 strings to save we would set the value for artist here as well:
         song.setValue(password, forKeyPath: "password")
        
        do {
            try managedContext.save()
        } catch let error as NSError {
            print("Could not save the song. \(error), \(error.userInfo)")
        }
    }
    
     // MARK: - Actions
    @IBAction func onAddBtn(_ sender: UIBarButtonItem) {
        
        // 1 make the alert that houses the alert actions
        let alert = UIAlertController(title: "New Input", message: "Add a password", preferredStyle: .alert)
        
        // 2
        // if we had a cancel action we would define it like so:
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
        
        let saveAction = UIAlertAction(title: "Save", style: .default) { [unowned self] action in
            guard let titleTextField = alert.textFields?[0],
                let title = titleTextField.text else { return }
            
            // if we had a second text field we add it here and use subscript notation like so
            guard let passwordTextField = alert.textFields?[1],
                
                let password = passwordTextField.text
                else { return }
            
            // if we were processing artist as well we would write saveSong like so instead:
            self.saveSong(title: title, password: password)
            //            self.saveSong(title: title)
            self.updateFromModel()
            self.tableView.reloadData()
        }
        
        // 3 adding ui elements AND actions to the alert. Adding UI elements is not that common.
        alert.addTextField(configurationHandler: { textField in
            textField.placeholder = "Title"
        })
        
        // if we wanted a 2nd text field we would add it here like so:
        alert.addTextField(configurationHandler: { textField in
            textField.placeholder = "Password"
            textField.isSecureTextEntry = true
        })
        
        alert.addAction(saveAction)
        
        // if we had a cancel action we would add it here:
        alert.addAction(cancelAction)
        
        // 4 There is no step 4 for this simple alert : )
        
        // 5 present the dialog
        present(alert, animated: true)
       
    }
    
   
}
