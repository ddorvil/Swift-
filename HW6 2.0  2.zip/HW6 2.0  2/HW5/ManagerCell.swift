//
//  ManagerCell.swift
//  HW5
//
//  Created by Dominique Dorvil on 10/26/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import Foundation
import UIKit

class ManagerCell : UITableViewCell{
    @IBOutlet weak var StrengthColor: UIView!
    
}
