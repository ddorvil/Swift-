//
//  TableViewController.swift
//  HW6
//
//  Created by Dominique Dorvil on 10/18/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import UIKit
import CoreData

let model = isValid()


class TableViewController: UITableViewController {
    
    var media: [NSManagedObject] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        self.title = "Password Manager"
        self.title = Bundle.main.object(forInfoDictionaryKey: "CFBundleName") as? String
        updateFromModel()
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return media.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ManagerCell", for: indexPath) as! ManagerCell
        let item = media[indexPath.row]
        cell.textLabel?.text = item.value(forKeyPath: "title") as? String
        
        // if we were updating the subtitle cell we would do it here
        cell.detailTextLabel?.text = item.value(forKeyPath: "password") as? String
        
        
        
        
        let strength = item.value(forKeyPath: "strength") as! Int
        
        switch strength {
        case 1:
            cell.StrengthColor.backgroundColor = UIColor.red
        case 2:
            cell.StrengthColor.backgroundColor = UIColor.orange
        case 3:
            cell.StrengthColor.backgroundColor = UIColor.yellow
        case 4:
            cell.StrengthColor.backgroundColor = UIColor.blue
        case 5:
            cell.StrengthColor.backgroundColor = UIColor.green
        default:
            cell.StrengthColor.backgroundColor = UIColor.black
        }
        
    
       
        return cell
    }
    
    // disallow swipe deletion when not in edit mode
    override func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return tableView.isEditing ? .delete : .none
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            if let manager = media[indexPath.row] as? Manager{
                deletionAlert(title: manager.title!) { _ in
                    self.deleteManager(manager: manager)
                }
            }
        }
    }
    
    // MARK: - Core Data
    
    func getObjectContext() -> NSManagedObjectContext {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        return appDelegate.persistentContainer.viewContext
    }
    
    func updateFromModel() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Manager")
        
        do {
            media = try managedContext.fetch(fetchRequest)
        } catch let error as NSError {
            print("Could not fetch requested media. \(error), \(error.userInfo)")
        }
    }
    
    // if we had 2 strings to save we would write this function like so instead:
    func saveSong(title: String, password: String, strength: Int) {
        let managedContext = getObjectContext()
        if let entity = NSEntityDescription.entity(forEntityName: "Manager", in:  managedContext) {
            let manager = NSManagedObject(entity: entity, insertInto:  managedContext)
            manager.setValue(title, forKey: "title")
            manager.setValue(password, forKey: "password")
            manager.setValue(strength, forKey: "strength")
//            manager.setValue(newTitle, forKey: "newTitle")
            do{
                try managedContext.save()
            } catch let error as NSError {
                print("Could not save the item. \(error), \(error.userInfo)")
            }
        }
    }
        
    func deleteManager (manager: Manager) {
        let managedContext = getObjectContext()
        if let _ = media.firstIndex(of: manager)  {
            managedContext.delete(manager)
            do {
                try managedContext.save()
            } catch let error as NSError {
                print("Could not delete the item. \(error), \(error.userInfo)")
            }
        }
        updateFromModel()
        tableView.reloadData()
    }
    
    // MARK: - Deletion Alert
    
    func deletionAlert(title: String, completion: @escaping (UIAlertAction) -> Void) {
        
        let alertMsg = "Are you sure you want to delete \(title)? This cannot be undone!"
        let alert = UIAlertController(title: "Warning", message: alertMsg, preferredStyle: .actionSheet)
        
        let deleteAction = UIAlertAction(title: "Delete", style: .destructive, handler: completion)
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler:nil)
        
        alert.addAction(cancelAction)
        alert.addAction(deleteAction)
        
        /*
         **  In this case we need a source for the popover as well, but don't have a handy UIBarButtonItem.
         **  As alternative we therefore use the sourceView/sourceRect combination and specify a rectangel
         **  centered in the view of our viewController.
         */
        alert.popoverPresentationController?.permittedArrowDirections = []
        alert.popoverPresentationController?.sourceView = self.view
        alert.popoverPresentationController?.sourceRect = CGRect(x: self.view.frame.midX, y: self.view.frame.midY, width: 0, height: 0)
        
        present(alert, animated: true, completion: nil)
    }

    
    // MARK: - Actions
        
    @IBAction func onToggleEdit(_ sender: UIBarButtonItem) {
            setEditing(!isEditing, animated: true)
        }
    @IBAction func onAddBtn(_ sender: UIBarButtonItem) {
        
        // 1 make the alert that houses the alert actions
        let alert = UIAlertController(title: "New Input", message: "Add a password", preferredStyle: .alert)
        
        // 2
        // if we had a cancel action we would define it like so:
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
        
        let saveAction = UIAlertAction(title: "Save", style: .default) { [unowned self] action in
            
            guard let titleTextField = alert.textFields?[0],
                let title = titleTextField.text else { return }
            
            // if we had a second text field we add it here and use subscript notation like so
            guard let passwordTextField = alert.textFields?[1],
                
                let password = passwordTextField.text
                else { return }
            
            let strength = model.checkStrength(password: password)
//             let newTitle = ""
            
            // if we were processing artist as well we would write saveSong like so instead:
            self.saveSong(title: title, password: password, strength: strength)
            //            self.saveSong(title: title)
            self.updateFromModel()
            self.tableView.reloadData()
            
            if strength <= 3{
                self.changePassword() //issue is here Dominique
            }
           
        }
        
        // 3 adding ui elements AND actions to the alert. Adding UI elements is not that common.
        alert.addTextField(configurationHandler: { textField in
            textField.placeholder = "Title"
        })
        
        // if we wanted a 2nd text field we would add it here like so:
        alert.addTextField(configurationHandler: { textField in
            textField.placeholder = "Password"
            textField.isSecureTextEntry = true
        })
        
        alert.addAction(saveAction)
        
        // if we had a cancel action we would add it here:
        alert.addAction(cancelAction)
        
        // 4 There is no step 4 for this simple alert : )
        
        // 5 present the dialog
        present(alert, animated: true)
       
    }
    
    func changePassword(){

        // 1 make the alert that houses the alert actions
        let alert = UIAlertController(title: "Change Password", message: "Low Strength", preferredStyle: .actionSheet)

        // 2
        // if we had a cancel action we would define it like so:
        let autoGenerate = UIAlertAction(title: "Auto-Password", style: .default){_ in
            let generated = model.generate()
            let item = self.media[self.media.count - 1]
            item.setValue(generated, forKey: "password")
            self.updateFromModel()
            self.tableView.reloadData()
//
//            let item2 = self.media[self.media.count - 1]
//            item2.setValue(generated, forKey: "password")
  
        }
        
        let keepSame = UIAlertAction(title: "Keep Password", style: .default){_ in
            self.tableView.reloadData()
            
        }
        
        let enter = UIAlertAction(title: "Re-Enter Password", style: .default){_ in

            
            let alert = UIAlertController(title: "Re-Enter Password", message: "Stength Low", preferredStyle: .alert)
            alert.addTextField { (textField) in
                textField.placeholder = "Password"
            }
            
//            alert.addAction(UIAlertAction(title: "Submit", style: .default, handler: { [weak alert] (_) in
//                guard let textField = alert?.textFields?[0], let userText = textField.text else { return }
            
            guard let titleTextField = alert.textFields?[0],
                let title = titleTextField.text else { return }
            
            alert.addAction(UIAlertAction(title: "Submit", style: .default) { [unowned self] action in
                guard let passwordTextField = alert.textFields?[0],
                    let newPassword = passwordTextField.text else { return }
                 passwordTextField.placeholder = "Passeword"
                passwordTextField.isSecureTextEntry = true
                
                
//                guard let titlesNewField = alert.textFields?[1],
//                    let newTF = titlesNewField.text else { return }
                
            let strength = model.checkStrength(password: newPassword)
                
            self.saveSong(title: title, password: newPassword, strength: strength)
            
                let item = self.media[self.media.count - 1]
                item.setValue( newPassword, forKey: "password")
//                item.setValue(newTF, forKey: "newTitle")
                self.updateFromModel()
                self.tableView.reloadData()
                
                if strength <= 3 {
                    self.changePassword()
                }
            });
            
            self.present(alert, animated: true, completion: nil)
        }
    
        //3
        alert.addAction(autoGenerate)
        alert.addAction(enter)
        alert.addAction(keepSame)
        

        // 4 There is no step 4 for this simple alert : )

        alert.popoverPresentationController?.permittedArrowDirections = []
        alert.popoverPresentationController?.sourceView = self.view
        alert.popoverPresentationController?.sourceRect = CGRect(x: self.view.frame.midX, y: self.view.frame.midY, width:0, height:0)


        // 5 present the dialog
        present(alert, animated: true, completion:nil)
    }
    
        
    }
    



