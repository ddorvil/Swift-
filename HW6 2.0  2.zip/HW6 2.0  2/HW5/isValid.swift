//
//  isValid.swift
//  HW5
//
//  Created by Dominique Dorvil on 10/26/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import UIKit

class isValid{
    

    func checkStrength(password: String) -> Int {
        
        var strength = 0
        let length: Int = password.count
        
        if length >= 8 {
            strength += 1
        }
        
        var upper = false
        var lower = false
        var number = false
        var symbol = false
        
        for ch in password{
            
            if ch.isUppercase && !upper{
                upper = true
                strength += 1
            }
            else if ch.isLowercase && !lower{
                lower = true
                strength += 1
            }
            else if ch.isNumber && !number{
                number = true
                strength += 1
            }
            else if (ch.isSymbol || ch.isMathSymbol || ch.isCurrencySymbol || ch.isPunctuation) && !symbol{
                symbol = true
                strength += 1
            }
        }
        
        return strength
    }

    
    func checkPassword(password: String) -> Int{
        
//        var strong = false
        var strength = 0
        let length: Int = password.count
        
        if length >= 8 {
            strength += 1
        }
        
        var upper = false
        var lower = false
        var number = false
        var symbol = false
        
        for ch in password{
            
            if ch.isUppercase && !upper{
                upper = true
                strength += 1
            }
            else if ch.isLowercase && !lower{
                lower = true
                strength += 1
            }
            else if ch.isNumber && !number{
                number = true
                strength += 1
            }
            else if (ch.isSymbol || ch.isMathSymbol || ch.isCurrencySymbol || ch.isPunctuation) && !symbol{
                symbol = true
                strength += 1
            }
        }
        
        print(strength)
        return strength
    }
        
    func generate() -> String? {

        
        let ucase = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]
        
        let lcase = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y" , "z"]
        
        let specialChar = ["!", "@", "#", "$", "%" ,"^", "&" , "*" , "?", "/", "(", ")", "+", "-"]
        
    //    let numbers = ["1, 2, 3, 4, 5 , 6, 7 , 8 , 9"]
        
        let number1 = String(Int.random(in:0..<10))
        let number2 = String(Int.random(in:0..<10))
        
    //    let newUcase = String((0..<2).compactMap{_ in ucase.randomElement() })
    //   print (newUcase)
        
        let ucase1 = ucase[Int.random(in: 0..<ucase.count)]
        let ucase2 = ucase[Int.random(in: 0..<ucase.count)]
    
        let lcase1 = lcase[Int.random(in: 0..<lcase.count)]
        let lcase2 = lcase[Int.random(in: 0..<lcase.count)]
        
        let schar1 = specialChar[Int.random(in: 0..<specialChar.count)]
        let schar2 = specialChar[Int.random(in: 0..<specialChar.count)]

        var password_arr = [ucase1, ucase2, lcase1, lcase2, schar1, schar2, number1 ,number2]
        //concatonate all the new randomized elements into the password
        
        password_arr.shuffle()
        
        var password = ""
        
        for c in password_arr{
            password += c
        }
        
//        var strength = 5
        
        print(checkPassword(password: password) )
        
        
        return password
    }
}

