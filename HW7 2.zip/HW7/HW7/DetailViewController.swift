//
//  DetailViewController.swift
//  HW7
//
//  Created by Dominique Dorvil on 11/10/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class DetailViewController: UIViewController, MKMapViewDelegate {

    @IBOutlet weak var tableView: UITableView!
    
    
    @IBOutlet weak var locationBtn: UIButton!

    var locationManager: CLLocationManager!
    var myLocation: CLLocation?
    
    @IBOutlet weak var snapshotImage: UIImageView!
    
    
    @IBOutlet weak var locationLabel: UILabel!
   
    @IBOutlet weak var VacayTitle: UITextField!
    @IBOutlet weak var remarksTextArea: UITextView!
    
    
    @IBAction func datePicker(_ sender: UIDatePicker) {
    }
    @IBOutlet weak var detailDescriptionLabel: UILabel!
    
    
    @IBOutlet weak var mapView: MKMapView!
    
    @IBAction func onLocation(_ sender: UITextField) {
    }
    
    @IBOutlet weak var LocationOutlet: UITextField!
    
    class SnapshotCustomCell: UITableViewCell{
        
    }
    class VacayCustomCell: UITableViewCell {
        @IBOutlet weak var VacayTitle: UITextField!
    }
    
    class DateCustomCell: UITableViewCell {
        
        @IBOutlet weak var datePicker: UIDatePicker!
        
    }
    
    class CostCustomCell: UITableViewCell {
         @IBOutlet weak var costEntry: UITextField!
        
    }
    
    class RemarksCustomCell: UITableViewCell {
        @IBOutlet weak var remarksEntry: UITextView!
        
        @IBOutlet weak var ratingEntry: UITextField!
        
    }
    
    class LocationCustomCell: UITableViewCell {
        
        @IBOutlet weak var longLabel: UILabel!
        @IBOutlet weak var latLabel: UILabel!
        
        @IBAction func onLocation(_ sender: UITextField) {
        }
        @IBOutlet weak var LocationOutlet: UITextField!
            @IBOutlet weak var mapView: MKMapView!
        
    }
    
    var locationStoring = CLLocation(latitude: 0.0, longitude: 0.0)
    
    var tableData = ["Vacay Title", "Date" ,"Cost", "Remarks", "Location"] as [Any]
    

    var detailItem: vacationItem? {
        didSet {
            // Update the view.
//            configureView()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.dataSource = (self as! UITableViewDataSource)
        tableView.delegate = (self as! UITableViewDelegate)
        tableView.tableFooterView = UIView()
//        configureView()
        
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        if let string = self.tableData[indexPath.row] as? String
        {
            let cell:VacayCustomCell = self.tableView.dequeueReusableCell(withIdentifier: "vacayCustomCell") as! VacayCustomCell
            
            cell.VacayTitle?.text = string
//            cell.countryIcon?.image = UIImage(named:string)
            return cell
        }
            
        else if let cost = self.tableData[indexPath.row] as? Any, cost is Float || cost is Int {
            
            let cell:CostCustomCell = self.tableView.dequeueReusableCell(withIdentifier: "costCustomCell") as! CostCustomCell
//            cell.costEntry?.text = cost as! String
            cell.costEntry?.text = "The trip cost \(cost) dollars"
            
            return cell
            
        }
        
        else if let remarks = self.tableData[indexPath.row] as? String {
            
            let cell:RemarksCustomCell = self.tableView.dequeueReusableCell(withIdentifier: "remarksCustomCell") as! RemarksCustomCell
           
            cell.remarksEntry?.text = remarks
            cell.ratingEntry?.text = remarks
            
            return cell
            
        }
        
        else if let date = self.tableData[indexPath.row] as? Any, date is Date {
            
            let cell:DateCustomCell = self.tableView.dequeueReusableCell(withIdentifier: "dateCustomCell") as! DateCustomCell
            
            cell.datePicker?.date = date as! Date
            
            return cell
            
        }
        
        else if let location = self.tableData[indexPath.row] as? Any, location is String {
            
            let cell:LocationCustomCell = self.tableView.dequeueReusableCell(withIdentifier: "locationCustomCell") as! LocationCustomCell
            
            cell.LocationOutlet?.text = location as! String
            cell.mapView?.mapType = location as! MKMapType
            
            return cell
            
        }
        
        return UITableViewCell()
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
//    func configureView() {
//        // Update the user interface for the detail item.
//        if let detail = detailItem {
//            if let label = VacayTitle {
//                label.text = detail.title
//            }
//
//            if let aDate = datePicker {
//                aDate.date = detail.date
//            }
//                if let locLabel = locationLabel {
//                }
//                if let cl = costEntry {
//                    cl.text = detail.cost.description
//                }
//                if let diary = remarksEntry {
//                    diary.text = detail.remarks
//                }
//                if let rate = ratingEntry {
//                    rate.text = detail.stars
//                }
//            if let l = LocationOutlet{
//                let xLocation = "\(detail.location!.coordinate.latitude)"
//                let yLocation = "\(detail.location!.coordinate.longitude)"
//                let toPrint = xLocation + "," + yLocation
//                l.text = toPrint
//            }
//
//        }
//}
//
//        override func viewWillDisappear(_ animated: Bool) {
//                super.viewWillDisappear(animated)
//                view.endEditing(true)
//                self.detailItem?.title = VacayTitle.text ?? ""
//                self.detailItem?.cost = Float(costEntry.text!)!
//                self.detailItem?.remarks = remarksEntry.text!
//                  self.detailItem?.stars = ratingEntry.text!
//                self.detailItem?.date = datePicker.date
//                self.detailItem?.location = locationStoring
//
//                mapView.delegate = self
//                mapView.mapType = .standard
//                mapView.isZoomEnabled = true
//                mapView.isScrollEnabled = true
//                mapView.removeAnnotations(mapView.annotations)
//                showMe()
//
//
//        }
//
//    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
//        print("Error getting location: " + error.localizedDescription)
//    }
//
//    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
//
//        if let location = locations.last {
//            myLocation = location
//            longLabel.text = myLocation?.coordinate.longitude.description
//            latLabel.text = myLocation?.coordinate.latitude.description
//        }
//    }
    
    // MARK: - Re-authorize Alert
    
    func missingPermissionsAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .actionSheet)
        let okAction = UIAlertAction(title: NSLocalizedString("str_ok", comment: ""), style: .cancel)
        let settingsAction = UIAlertAction(title: NSLocalizedString("str_settings", comment: ""), style: .default) { _ in
            UIApplication.shared.open(URL(string: UIApplication.openSettingsURLString)!)
        }
        
        alert.addAction(okAction)
        alert.addAction(settingsAction)
        present(alert, animated: true)
    }
    
    // MARK: - Actions
    
    @IBAction func onStartBtn(_ sender: Any) {
        switch CLLocationManager.authorizationStatus() {
        case .denied:
            missingPermissionsAlert(title: NSLocalizedString("str_CLNoService", comment: ""),
                                    message: NSLocalizedString("str_CLDeniedPerm", comment: ""))
        case .restricted:
            missingPermissionsAlert(title: NSLocalizedString("str_CLNoService", comment: ""),
                                    message: NSLocalizedString("str_CLBlocked", comment: ""))
        default:
            locationManager.requestWhenInUseAuthorization()
            locationManager.startUpdatingLocation()
            locationBtn.isEnabled = true
        }
    }

    
    func showMe() {
        
        if let coord = myLocation?.coordinate {
            let deltas = MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
            let region = MKCoordinateRegion(center: coord, span: deltas)
            mapView.setRegion(region, animated: true)
            
            let annotation = MKPointAnnotation()
            annotation.coordinate = coord
            annotation.title = "You are here!"
            mapView.addAnnotation(annotation)
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first!
        let location = touch.location(in: self.view)
        let xLocation = "\(location.x)"
        let yLocation = "\(location.y)"
        let toPrint = xLocation + "," + yLocation
        LocationOutlet.text = toPrint
        
        locationStoring = CLLocation(latitude: Double(location.x), longitude: Double(location.y))
        
        
    }

}



