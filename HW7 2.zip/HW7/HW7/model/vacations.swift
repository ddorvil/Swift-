//
//  vacations.swift
//  Vacays
//
//  Created by Dominique Dorvil on 11/10/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import Foundation

import UIKit

import MapKit

class vacations: Codable {
    
    var items = [vacationItem]()
    
    // MARK: - Utilty
    
    func add(title: String) {
        let vacayItem = vacationItem(title: title)
//                                    date: String,
//                                    remarks: String,
//                                    cost: Float,
//                                    location: CLLocation,
//                                    image: UIImage,
//                                    uid: UUID())
        items.insert(vacayItem, at: 0)
    }
    
    func move(fromIndex: Int, toIndex: Int) {
        if fromIndex != toIndex {
            let item = items[fromIndex]
            items.remove(at: fromIndex)
            items.insert(item, at: toIndex)
        }
    }
    
    func removeItem(at index: Int) {
        if let _ = items[index] as vacationItem? {
            items.remove(at: index)
        }
    }
}
