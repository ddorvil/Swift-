//
//  vacationItem.swift
//  Vacays
//
//  Created by Dominique Dorvil on 11/10/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import Foundation
import UIKit
import MapKit

enum CodingKeys: String, CodingKey{
    
    case title, date, remarks, cost, image, location, uuid
}

class vacationItem: Codable {
    var title: String
    var date: Date
    var remarks: String
    var cost: Float
    var image: UIImage?
    var location: CLLocation?
    var uuid: UUID
    
    init(title: String) {
        self.title = title
        self.cost = 0.0
        self.date = Date()
        self.remarks = ""
        self.location = CLLocation()
        self.image = UIImage(named: "hw7Icon-80")
        self.uuid = UUID()
        
    }
    
    required init (from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        title = try container.decode(String.self, forKey: .title)
        cost = try container.decode(Float.self, forKey: .cost)
        remarks = try container.decode(String.self, forKey: .remarks)
        uuid = try container.decode(UUID.self, forKey: .uuid)
        date = try container.decode(Date.self, forKey: .date)
        
        if let imageData = try container.decodeIfPresent(Data.self, forKey: .image) {
            image = try NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(imageData) as? UIImage } else {
                    image = nil
            
        }
        
        if let locationData = try container.decodeIfPresent(Data.self, forKey: .location) {
            location = try NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(locationData) as? CLLocation } else {
            location = nil
            
        }
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        
        try container.encode(title, forKey: .title)
        try container.encode(cost, forKey: .cost)
        try container.encode(remarks, forKey: .remarks)
        try container.encode(uuid, forKey: .uuid)
        try container.encode(date, forKey: .date)
        if let img = image {
            let imageData = try NSKeyedArchiver.archivedData(withRootObject: img, requiringSecureCoding: false)
            try container.encode(imageData, forKey: .image)
        }
        
        if let loc = location {
            let locData = try NSKeyedArchiver.archivedData(withRootObject: loc, requiringSecureCoding: false)
            try container.encode(locData, forKey: .location)
        }
    }
    
    
    
}
