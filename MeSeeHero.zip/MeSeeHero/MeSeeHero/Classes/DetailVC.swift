//
//  DetailVC.swift
//  MeSeeHero
//
//  Created by Dominique Dorvil on 11/3/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import UIKit


class DetailVC: UIViewController {

    
    @IBOutlet weak var backgroundImage: UIImageView!
    @IBOutlet weak var logoImageView: UIImageView!
    
    
    var item: Entry?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = item?.location
        logoImageView.image = UIImage(data: item?.logo! as! Data)
        backgroundImage.image = UIImage(data: item?.snapshot! as! Data)
       
        
    }
    
    

    func updateType(type: Int) {
        if HeroType(rawValue: type) != nil {
//        if let heroType = HeroType(rawValue: type) {
//            titleImageView.image = heroType.image()
        }
    }
}
