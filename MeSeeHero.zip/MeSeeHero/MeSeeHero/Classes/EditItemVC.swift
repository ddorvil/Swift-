//
//  EditItemVC.swift
//  MeSeeHero
//
//  Created by Dominique Dorvil on 11/2/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import UIKit



protocol EditItemDelegate: class {
    func addedHeroItem()
}

class EditItemVC: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate{
    
    
    @IBOutlet weak var backgroundView: UIImageView!
    @IBOutlet weak var heroView: UIImageView!
    
//    @IBOutlet weak var imagePicker: UIPickerView!
    
    @IBOutlet weak var residencePicker: UIPickerView!
    var cityData: [String] = [String]()
    
    
    @IBOutlet weak var zodiacPicker: UIPickerView!
    var zodiacData: [String] = [String]()
    
    @IBOutlet weak var lastSeen: UILabel!
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var addBtn: UIButton!
    @IBOutlet weak var cancelBtn: UIButton!
    var inputName: String?
//    var inputCity: String?
    var inputLocation: String?
    var heroImage: UIImage?
    var backImage: UIImage?
    
    var flag: Int = 0
    
    weak var delegate: EditItemDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.zodiacPicker.delegate = self
        self.zodiacPicker.dataSource = self
        
        self.residencePicker.delegate = self
        self.residencePicker.dataSource = self
        
        lastSeen.text = NSLocalizedString("str_lastSeen", comment: "")
        name.text = NSLocalizedString("str_name", comment: "")
        
        addBtn.setTitle(NSLocalizedString("str_addBtn", comment: ""), for: .normal)
        cancelBtn.setTitle(NSLocalizedString("str_cancelBtn", comment: ""), for: .normal)
    
        
        zodiacData = [NSLocalizedString("zodiac1", comment: ""), NSLocalizedString("zodiac2", comment: ""),NSLocalizedString("zodiac3", comment: ""), NSLocalizedString("zodiac4", comment: ""), NSLocalizedString("zodiac5", comment: ""), NSLocalizedString("zodiac6", comment: ""), NSLocalizedString("zodiac7", comment: ""), NSLocalizedString("zodiac8", comment: ""), NSLocalizedString("zodiac9", comment: ""), NSLocalizedString("zodiac10", comment: ""), NSLocalizedString("zodiac11", comment: ""), NSLocalizedString("zodiac12", comment: "")]
        
         cityData = [NSLocalizedString("city1", comment: ""), NSLocalizedString("city2", comment: ""),NSLocalizedString("city3", comment: ""), NSLocalizedString("city4", comment: ""), NSLocalizedString("city5", comment: ""), NSLocalizedString("city6", comment: ""), NSLocalizedString("city7", comment: ""), NSLocalizedString("city8", comment: ""), NSLocalizedString("city9", comment: ""), NSLocalizedString("city10", comment: ""), NSLocalizedString("city11", comment: ""), NSLocalizedString("city12", comment: "")]
        
        cityData =  ["Metropolis", "Star", "Gotham", "Coast", "Midway", "NYC", "Ivy", "Fawcett", "Opal", "Astro", "City", "Doomsdale"]
        
         zodiacData = ["Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo", "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"]
        
    }
    
    func nameAlert() {
        
        let alertMsg = "Missing name!"
        let alert = UIAlertController(title: "Warning", message: alertMsg, preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler:nil)
        
        alert.addAction(cancelAction)
        
        /*
         **  In this case we need a source for the popover as well, but don't have a handy UIBarButtonItem.
         **  As alternative we therefore use the sourceView/sourceRect combination and specify a rectangel
         **  centered in the view of our viewController.
         */
        alert.popoverPresentationController?.permittedArrowDirections = []
        alert.popoverPresentationController?.sourceView = self.view
        alert.popoverPresentationController?.sourceRect = CGRect(x: self.view.frame.midX, y: self.view.frame.midY, width: 0, height: 0)
        
        present(alert, animated: true, completion: nil)
    }
    
    func locationAlert() {
        
        let alertMsg = "Missing Last Seen!"
        let alert = UIAlertController(title: "Warning", message: alertMsg, preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler:nil)
        
        alert.addAction(cancelAction)
        
        /*
         **  In this case we need a source for the popover as well, but don't have a handy UIBarButtonItem.
         **  As alternative we therefore use the sourceView/sourceRect combination and specify a rectangel
         **  centered in the view of our viewController.
         */
        alert.popoverPresentationController?.permittedArrowDirections = []
        alert.popoverPresentationController?.sourceView = self.view
        alert.popoverPresentationController?.sourceRect = CGRect(x: self.view.frame.midX, y: self.view.frame.midY, width: 0, height: 0)
        
        present(alert, animated: true, completion: nil)
    }
    
  
    // MARK: - Actions
    
    @IBAction func onNameChange(_ sender: UITextField) {
        if let newValue = sender.text {
            if newValue == ""{
                nameAlert()
            }
            inputName = newValue
            
        }
        else {
            nameAlert()
        }
    
    }
    
    @IBAction func onLocationChange(_ sender: UITextField) {
        if let newValue = sender.text {
            if newValue == "" {
                locationAlert()
            }
            inputLocation = newValue
        } else {
            locationAlert()
        }
    }
    
//    @IBAction func onCityChange(_ sender: UITextField) {
//        if let newValue = sender.text {
//            inputCity = newValue
//        }
//    }
//
    @IBAction func onCanel(_ sender: UIButton) {
        presentingViewController?.dismiss(animated: true)
    }
    
    @IBAction func onAdd(_ sender: UIButton) {
        if inputName == nil {
            nameAlert()
            return
        }
        
        if inputLocation == nil {
            locationAlert()
            return
        }
        
        if let name = inputName, let location = inputLocation, let logoImage = heroImage, let userBackground = backImage{
            if name == "" {
                nameAlert()
            }
            if location == "" {
                locationAlert()
            }
            CoreDataStack.shared.saveItem(city: Int16(residencePicker.selectedRow(inComponent: 0)), name: name,
                                          zodiac: Int16(zodiacPicker.selectedRow(inComponent: 0)),
                                          location: location,
//                                          logo: String,
                                            logo: logoImage.pngData()! as NSData,
                                            snapshot: userBackground.pngData()! as NSData)
            
//            snapshot: backImage?.pngData() as! NSData
            delegate?.addedHeroItem()
        }
        presentingViewController?.dismiss(animated: true)
        
        
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Actions
    
    @IBAction func onChangeHeroBtn(_ sender: UIButton) {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.allowsEditing = true
        picker.sourceType = .photoLibrary
        present(picker, animated: true, completion: nil)
        flag = 1;
        
    }
    
    @IBAction func snapShotChange(_ sender: UIButton) {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.allowsEditing = true
        picker.sourceType = .photoLibrary
        present(picker, animated: true, completion: nil)
        flag = 2;
        
        
    }
    
    // MARK: - UIImagePickerControllerDelegate
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[.editedImage] as? UIImage  {
            if flag == 1 {
                heroView.image = image
                heroImage = image
            }
            else {
                backgroundView.image = image
                backImage = image
            }
        }
        
        dismiss(animated: true, completion: nil)
    }
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
    
  
}


//These pickers need to be edited. I am a little confused on what's going on
extension EditItemVC: UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView.tag == 0 {
            return zodiacData.count
        } else if pickerView.tag == 1 {
            return cityData.count
        } else {
            return HeroType.allValues.count
        }
    }
}
extension EditItemVC: UIPickerViewDelegate {
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView.tag == 0 {
            return zodiacData[row]
        } else if pickerView.tag == 1 {
            return cityData[row]
        } else {
            return HeroType(rawValue: row)?.title()
        }
    }
}

