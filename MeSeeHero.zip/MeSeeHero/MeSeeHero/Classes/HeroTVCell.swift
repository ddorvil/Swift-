//
//  HeroTVCell.swift
//  MeSeeHero
//
//  Created by Dominique Dorvil on 11/2/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import UIKit

class HeroTVCell: UITableViewCell {
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var zodiacLabel: UILabel!
    @IBOutlet weak var logoImageView: UIImageView!
    
   
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        nameLabel.text = NSLocalizedString("str_name", comment: "")
        cityLabel.text = NSLocalizedString("str_city", comment: "")
        zodiacLabel.text = NSLocalizedString("str_zodiac", comment: "")
       
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
//    func updateLogo(type: Int) {
//        if let heroType = HeroType(rawValue: type) {
//            logoImageView.image = heroType.image()
//        }
//    }
    
    func updateZodiac(type: Int) {

        if let zType = zodiacType(rawValue: type) {
            print(zType)
            zodiacLabel.text = zType.title()
            print(zType.title())
        }
        
    }
    
    func updateCity(type: Int) {
        if let cType = cityType(rawValue: type) {
            cityLabel.text = cType.title()
        }
        
    }
    
//    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//    }
    
}
