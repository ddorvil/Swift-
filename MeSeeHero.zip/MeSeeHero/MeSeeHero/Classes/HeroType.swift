//
//  HeroType.swift
//  MeSeeHero
//
//  Created by Dominique Dorvil on 11/2/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import Foundation
import UIKit

enum HeroType: Int {
    case batman, xmen, flash, cWomen, wWomen
    static let allValues = [batman, xmen, flash, cWomen, wWomen]
    
    func title() -> String {
        switch self {
        case .batman:
            return "Batman"
        case .xmen:
            return "Xmen"
        case .flash:
            return "Flash"
        case .cWomen:
            return "Cat Woman"
        case .wWomen:
            return "Wonder Woman"
        }
    }
    
    func image() -> UIImage? {
        switch self {
        case .batman:
            return UIImage(named: "logo_batman")
        case .xmen:
            return UIImage(named: "logo_xmen")
        case .flash:
            return UIImage(named: "logo_flash")
        case .cWomen:
            return UIImage(named: "logo_cwoman")
        case .wWomen:
            return UIImage(named: "logo_wwoman")
            
        
        }
    }
    
}

enum zodiacType: Int {
    case Aries, Taurus, Gemini, Cancer, Leo, Virgo, Libra, Scorpio, Sagittarius, Capricorn, Aquarius, Pisces
    static let allValues = [ Aries, Taurus, Gemini, Cancer, Leo, Virgo, Libra, Scorpio, Sagittarius, Capricorn, Aquarius, Pisces]
    
    func title() -> String {
        switch self {
        case .Aries:
            return "Aries"
        case .Taurus:
            return "Taurus"
        case .Gemini:
            return "Gemini"
        case .Cancer:
            return "Cancer"
        case .Leo:
            return "Leo"
        case .Virgo:
            return "Virgo"
        case .Libra:
            return "Libra"
        case .Scorpio:
            return "Scorpio"
        case .Sagittarius:
            return "Sagittarius"
        case .Capricorn:
            return "Capricorn"
        case .Aquarius:
            return "Aquarius"
        case .Pisces:
            return "Pisces"
        }
    }
    
   
    
}

enum cityType: Int {

    
    case Metropolis, Star, Gotham , Coast, Midway, NYC, Ivy, Fawcett, Opal , Astro, City, Doomsdale
    static let allValues = [Metropolis, Star, Gotham, Coast, Midway, NYC, Ivy, Fawcett, Opal, Astro, City, Doomsdale]
    
    func title() -> String {
        switch self {
        case . Metropolis:
            return "Metropolis"
        case .Star:
            return "Star"
        case .Gotham:
            return "Gotham"
        case .Coast:
            return "Coast"
        case .Midway:
            return "Midway"
        case . NYC:
            return "NYC"
        case .Ivy:
            return "Ivy"
        case .Fawcett:
            return "Fawcett"
        case .Opal:
            return "Opal"
        case .Astro:
            return "Astro"
        case .City:
            return "City"
        case .Doomsdale:
            return "Doomsdale"
        }
    }
    
    
    
}



