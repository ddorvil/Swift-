//
//  CoreDataStack.swift
//  MeSeeHero
//
//  Created by Dominique Dorvil on 11/2/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import Foundation
import CoreData

//is this file generated or created?

final class CoreDataStack: NSObject {
    
    static let shared = CoreDataStack()
    
    let modelName = "MeSeeHero"
    
    lazy var context: NSManagedObjectContext = {
        return self.persistentContainer.viewContext
    }()
    
    lazy var persistentContainer: NSPersistentContainer = {
        
        let container = NSPersistentContainer(name: "MeSeeHero")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    var entries: [NSManagedObject] = []
    
    // MARK: - Core Data operations
    
    func update() {
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Entry")
        do {
            entries = try context.fetch(fetchRequest)
        } catch let error as NSError {
            print("Could not fetch requested item. \(error), \(error.userInfo)")
        }
    }
    
    //Does snapshot belong here
    func saveItem(city: Int16, name: String, zodiac: Int16, location: String, logo: NSData, snapshot: NSData) {
        
        if let entity = NSEntityDescription.entity(forEntityName: "Entry", in: context) {
            let entry = NSManagedObject(entity: entity, insertInto: context)
            entry.setValue(name, forKeyPath: "name")
            print("value of zodiac")
            print(zodiac)
            entry.setValue(zodiac, forKeyPath: "zodiac")
            entry.setValue(location, forKeyPath: "location")
            entry.setValue(city, forKeyPath: "city")
            entry.setValue(logo, forKeyPath: "logo")
            entry.setValue(snapshot, forKeyPath: "snapshot")
            do {
                try context.save()
            } catch let error as NSError {
                print("Could not save the item. \(error), \(error.userInfo)")
                
            }
        }
        
        
        update()
        
        
    }
    
    func deleteItem(item: Entry) {
        if let _ = entries.firstIndex(of: item)  {
            context.delete(item)
            do {
                try context.save()
            } catch let error as NSError {
                print("Could not delete the item. \(error), \(error.userInfo)")
            }
        }
        update()
    }
    
    func saveContext () {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    
}

