//
//  Entry+CoreDataClass.swift
//  MeSeeHero
//
//  Created by Dominique Dorvil on 11/7/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Entry)
public class Entry: NSManagedObject {
    
    override public func awakeFromInsert() {
        if self.uuid == nil {
            self.uuid = UUID()
        }
    }
}
