//
//  Entry+CoreDataProperties.swift
//  MeSeeHero
//
//  Created by Dominique Dorvil on 11/7/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//
//

import Foundation
import CoreData


extension Entry {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Entry> {
        return NSFetchRequest<Entry>(entityName: "Entry")
    }

    @NSManaged public var city: Int16
    @NSManaged public var location: String?
    @NSManaged public var logo: NSData?
    @NSManaged public var name: String?
    @NSManaged public var snapshot: NSData?
    @NSManaged public var uuid: UUID?
    @NSManaged public var zodiac: Int16

}
