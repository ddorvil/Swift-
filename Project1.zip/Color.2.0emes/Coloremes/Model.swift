//
//  GetHex.swift
//  Coloremes
//
//  Created by Dominique Dorvil on 9/27/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import Foundation
import UIKit

class Model {
    
    func getText(num: Int) -> String{
        
        switch num {
        case 1:
            return "ECC66E"
        case 2:
            return "FFC800"
        case 3:
            return "7F3000"
        case 4:
            return "612846"
        case 5:
            return "B58944"
        case 6:
            return "D1D1D1"
        case 7:
            return "FF7400"
        case 8:
            return "C2453B"
        case 9:
            return "7F8B5F"
        case 10:
            return "A75F0F"
        case 11:
            return "FF2400"
        case 12:
            return "FFE645"
        case 13:
            return "DEA1A6"
        case 14:
            return "42283E"
        case 15:
            return "651200"
        case 16:
            return "B25641"
        
        default:
            return "placeholder"
        }
    }
    
    func getColor(num: Int) -> UIColor{
        switch num {
        case 1:
            return #colorLiteral(red: 0.9254901961, green: 0.7764705882, blue: 0.431372549, alpha: 1)
        case 2:
            return #colorLiteral(red: 1, green: 0.7843137255, blue: 0, alpha: 1)
        case 3:
            return #colorLiteral(red: 0.4980392157, green: 0.1882352941, blue: 0, alpha: 1)
        case 4:
            return #colorLiteral(red: 0.3803921569, green: 0.1568627451, blue: 0.2745098039, alpha: 1)
        case 5:
            return #colorLiteral(red: 0.7098039216, green: 0.537254902, blue: 0.2666666667, alpha: 1)
        case 6:
            return #colorLiteral(red: 0.8196078431, green: 0.8196078431, blue: 0.8196078431, alpha: 1)
            
        case 7:
            return #colorLiteral(red: 1, green: 0.4549019608, blue: 0, alpha: 1)
        case 8:
            return #colorLiteral(red: 0.7607843137, green: 0.2705882353, blue: 0.231372549, alpha: 1)
        case 9:
            return #colorLiteral(red: 0.4980392157, green: 0.5450980392, blue: 0.3725490196, alpha: 1)
        case 10:
            return #colorLiteral(red: 0.6549019608, green: 0.3725490196, blue: 0.05882352941, alpha: 1)  
        case 11:
            return #colorLiteral(red: 1, green: 0.1411764706, blue: 0, alpha: 1)
        case 12:
            return #colorLiteral(red: 1, green: 0.9019607843, blue: 0.2705882353, alpha: 1)
        case 13:
            return #colorLiteral(red: 0.8705882353, green: 0.631372549, blue: 0.6509803922, alpha: 1)
        case 14:
            return #colorLiteral(red: 0.2588235294, green: 0.1568627451, blue: 0.2431372549, alpha: 1)
        case 15:
            return #colorLiteral(red: 0.3960784314, green: 0.07058823529, blue: 0, alpha: 1)
        case 16:
            return #colorLiteral(red: 0.6980392157, green: 0.337254902, blue: 0.2549019608, alpha: 1)
            
        default:
            return UIColor.black
        }
    }
}






















