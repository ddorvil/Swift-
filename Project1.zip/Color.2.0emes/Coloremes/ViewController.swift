//
//  ViewController.swift
//  Coloremes
//
//  Created by Dominique Dorvil on 9/27/19.
//  Copyright © 2019 Dominique Dorvil. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var colorView: UIView!
     @IBOutlet weak var hexView: UILabel!
   
    let model  = Model()
    @IBAction func tapAction(_ sender: UITapGestureRecognizer) {
        hexView.text = model.getText(num: 1)
        colorView.backgroundColor = model.getColor(num: 1)
    }
    
    @IBAction func tapAction3(_ sender: Any) {
         hexView.text = model.getText(num: 3)
         colorView.backgroundColor = model.getColor(num: 3)
    }
    @IBAction func tapAction2(_ sender: UITapGestureRecognizer) {
        hexView.text = model.getText(num: 2)
        colorView.backgroundColor = model.getColor(num: 2)
        
    }
    
    @IBAction func tapAction4(_ sender: UITapGestureRecognizer) {
        hexView.text = model.getText(num: 4)
        colorView.backgroundColor = model.getColor(num: 4)
    }
    
    @IBAction func tapAction5(_ sender: UITapGestureRecognizer) {
        
        hexView.text = model.getText(num: 5)
        colorView.backgroundColor = model.getColor(num: 5)
    }
    
    
    @IBAction func tapAction6(_ sender: UITapGestureRecognizer) {
    hexView.text = model.getText(num: 6)
    colorView.backgroundColor = model.getColor(num: 6)
    }
   
   
    @IBAction func tapAction7(_ sender: UITapGestureRecognizer) {
    hexView.text = model.getText(num: 7)
        colorView.backgroundColor = model.getColor(num: 7)
    }

   
    @IBAction func tapAction8(_ sender: UITapGestureRecognizer) {
    
        hexView.text = model.getText(num: 8)
        colorView.backgroundColor = model.getColor(num: 8)
    }
    
   
    @IBAction func tapAction9(_ sender: UITapGestureRecognizer) {
    
        hexView.text = model.getText(num: 9)
        colorView.backgroundColor = model.getColor(num: 9)
    }

    @IBAction func tapAction10(_ sender: UITapGestureRecognizer) {
        hexView.text = model.getText(num: 10)
        colorView.backgroundColor = model.getColor(num: 10)
    }


    @IBAction func tapAction11(_ sender: UITapGestureRecognizer) {
        hexView.text = model.getText(num: 11)
        colorView.backgroundColor = model.getColor(num: 11)
    }

    @IBAction func tapAction12(_ sender: UITapGestureRecognizer) {
        hexView.text = model.getText(num: 12)
        colorView.backgroundColor = model.getColor(num: 12)
    }


    @IBAction func tapAction13(_ sender: UITapGestureRecognizer) {
        hexView.text = model.getText(num: 13)
        colorView.backgroundColor = model.getColor(num: 13)
    }


    @IBAction func tapAction14(_ sender: UITapGestureRecognizer) {
        hexView.text = model.getText(num: 14)
        colorView.backgroundColor = model.getColor(num: 14)
    }

    @IBAction func tapAction15(_ sender: UITapGestureRecognizer) {
        hexView.text = model.getText(num: 15)
        colorView.backgroundColor = model.getColor(num: 15)
    }


    @IBAction func tapAction16(_ sender: UITapGestureRecognizer) {
        hexView.text = model.getText(num: 16)
        colorView.backgroundColor = model.getColor(num: 16)
    }



    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }






    
}

